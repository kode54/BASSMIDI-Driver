/*
    BASSMIDI Driver - Ripped wholesale off the TiMidity++ driver
*/

//#define DEBUG
#define STRICT
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0400
#endif

#if __DMC__
unsigned long _beginthreadex( void *security, unsigned stack_size,
		unsigned ( __stdcall *start_address )( void * ), void *arglist,
		unsigned initflag, unsigned *thrdaddr );
void _endthreadex( unsigned retval );
#endif

#include <stdio.h>

#include <windows.h>
#include "mmddk.h"  
#include <mmsystem.h>
#include <tchar.h>
#if defined(__DMC__) || defined(__MINGW32__)
//following codes are from wine's mmsystem.h 
typedef struct tagMIDIOUTCAPS2A {
    WORD	wMid;
    WORD	wPid;
    MMVERSION	vDriverVersion;
    CHAR	szPname[MAXPNAMELEN];
    WORD	wTechnology;
    WORD	wVoices;
    WORD	wNotes;
    WORD	wChannelMask;
    DWORD	dwSupport;
    GUID	ManufacturerGuid;
    GUID	ProductGuid;
    GUID	NameGuid;
} MIDIOUTCAPS2A, *LPMIDIOUTCAPS2A;

typedef struct tagMIDIOUTCAPS2W {
    WORD	wMid;
    WORD	wPid;
    MMVERSION	vDriverVersion;
    WCHAR	szPname[MAXPNAMELEN];
    WORD	wTechnology;
    WORD	wVoices;
    WORD	wNotes;
    WORD	wChannelMask;
    DWORD	dwSupport;
    GUID	ManufacturerGuid;
    GUID	ProductGuid;
    GUID	NameGuid;
} MIDIOUTCAPS2W, *LPMIDIOUTCAPS2W;

//DECL_WINELIB_TYPE_AW(MIDIOUTCAPS2)
//DECL_WINELIB_TYPE_AW(LPMIDIOUTCAPS2)
#endif

#include <process.h>

// GUID definitions from wine's guiddef.h
#ifndef GUID_DEFINED
#define GUID_DEFINED
typedef struct _GUID
{
    unsigned long  Data1;
    unsigned short Data2;
    unsigned short Data3;
    unsigned char  Data4[ 8 ];
} GUID;

#endif

const GUID CLSID_bassmidi_synth = { 0xa675eda2, 0xeb26, 0x4e32, { 0xa3, 0xe7, 0xe4, 0xe6, 0x61, 0xd8, 0xfc, 0x3f } };

#include "../bass.h"
#include "../bassmidi.h"

LONG driverCount;

static volatile int OpenCount = 0;
static volatile int modm_closed = 1;

static CRITICAL_SECTION mim_section;
static volatile int stop_thread = 0;
static volatile int stop_rtthread = 0;
static HANDLE hCalcThread = NULL;
static HANDLE hRtsynThread = NULL;
static DWORD processPriority;

static unsigned int font_count = 0;
static HSOUNDFONT * hFonts = NULL;
static HSTREAM hStream = 0;;

static BYTE gs_part_to_ch[16];
static BYTE drum_channels[16];

static void ResetDrumChannels()
{
	static const BYTE part_to_ch[16] = {9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15};

	unsigned i;

	memset( drum_channels, 0, sizeof( drum_channels ) );
	drum_channels[ 9 ] = 1;

	memcpy( gs_part_to_ch, part_to_ch, sizeof( gs_part_to_ch ) );

	if ( hStream )
	{
		for ( i = 0; i < 16; ++i )
		{
			BASS_MIDI_StreamEvent( hStream, i, MIDI_EVENT_DRUMS, drum_channels[ i ] );
		}
	}
}

static void FreeFonts()
{
	unsigned i;
	if ( hFonts && font_count )
	{
		for ( i = 0; i < font_count; ++i )
		{
			BASS_MIDI_FontFree( hFonts[ i ] );
		}
		free( hFonts );
		hFonts = NULL;
		font_count = 0;
	}
}

void LoadFonts(const TCHAR * name)
{
	const DWORD bass_flags =
#ifdef UNICODE
		BASS_UNICODE
#else
		0
#endif
		;

	FreeFonts();

	if (name && *name)
	{
		const TCHAR * ext = _tcsrchr( name, _T('.') );
		if ( ext ) ext++;
		if ( !_tcsicmp( ext, _T("sf2") ) || !_tcsicmp( ext, _T("sf2pack") ) )
		{
			font_count = 1;
			hFonts = malloc( sizeof(HSOUNDFONT) );
			*hFonts = BASS_MIDI_FontInit( name, bass_flags );
		}
		else if ( !_tcsicmp( ext, _T("sflist") ) )
		{
			FILE * fl = _tfopen( name, _T("r, ccs=UTF-8") );
			font_count = 0;
			if ( fl )
			{
				TCHAR path[1024], fontname[1024], temp[1024];
				const TCHAR * filename = _tcsrchr( name, _T('\\') ) + 1;
				if ( filename == (void*)1 ) filename = _tcsrchr( name, _T(':') ) + 1;
				if ( filename == (void*)1 ) filename = name;
				_tcsncpy( path, name, filename - name );
				path[ filename - name ] = 0;
				while ( !feof( fl ) )
				{
					TCHAR * cr;
					if( !_fgetts( fontname, 1024, fl ) ) break;
					fontname[1023] = 0;
					cr = _tcsrchr( fontname, _T('\n') );
					if ( cr ) *cr = 0;
					if ( isalpha( fontname[0] ) && fontname[1] == _T(':') )
					{
						cr = fontname;
					}
					else
					{
						_tcscpy( temp, path );
						_tcscat( temp, fontname );
						cr = temp;
					}
					font_count++;
					hFonts = realloc( hFonts, sizeof(HSOUNDFONT) * font_count );
					hFonts[ font_count - 1 ] = BASS_MIDI_FontInit( cr, bass_flags );
				}
				fclose( fl );
			}
		}
	}
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved ){
	if (fdwReason == DLL_PROCESS_ATTACH){
		DisableThreadLibraryCalls(hinstDLL);
	}else if(fdwReason == DLL_PROCESS_DETACH){
		;
	}
	return TRUE;    
}

STDAPI DllCanUnloadNow(void){
	return S_OK;
}

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID * ppv){
	return S_OK;
}

STDAPI DllRegisterServer(void){
	return S_OK;
}

STDAPI DllUnregisterServer(void)
{
	return S_OK;
}


//unsigned __stdcall threadfunc2(LPVOID lpV);
//STDAPI_(LONG) DefDriverProc(DWORD dwDriverId, HDRVR hdrvr, UINT msg, LONG lParam1, LONG lParam2);

STDAPI_(LONG) DriverProc(DWORD dwDriverId, HDRVR hdrvr, UINT msg, LONG lParam1, LONG lParam2){
 
	switch(msg) {
	case DRV_REMOVE:
		if (modm_closed == 0){
			int maxloop=500;
			
			stop_thread = 1;    //why thread can't stop by this????
			while( stop_thread != 0 && maxloop-- > 0) Sleep(10);
			if(stop_thread == 0) {
				stop_rtthread = 1;
				while( stop_rtthread != 0 && maxloop-- > 0) Sleep(10);
			}
			if(stop_thread != 0) TerminateThread(hCalcThread, FALSE);
			if(stop_rtthread != 0) TerminateThread(hRtsynThread, FALSE);
			CloseHandle(hRtsynThread);
			CloseHandle(hCalcThread);
			SetPriorityClass(GetCurrentProcess(), processPriority);
		}
		DeleteCriticalSection(&mim_section);
		return 1;
	case DRV_LOAD:
		processPriority = GetPriorityClass(GetCurrentProcess());
		InitializeCriticalSection(&mim_section);
		return 1;
	case DRV_CLOSE:
	case DRV_CONFIGURE:
	case DRV_DISABLE:
	case DRV_ENABLE:
	case DRV_EXITSESSION:
	case DRV_FREE:
	case DRV_INSTALL:
	case DRV_OPEN:
	case DRV_POWER:
	case DRV_QUERYCONFIGURE:
	default:
		return 1;
		break;
		return DefDriverProc(dwDriverId, hdrvr, msg, lParam1, lParam2);
		break;
	}
	return DefDriverProc(dwDriverId, hdrvr, msg, lParam1, lParam2);
}

HRESULT modGetCaps(PVOID capsPtr, DWORD capsSize) {
	MIDIOUTCAPSA * myCapsA;
	MIDIOUTCAPSW * myCapsW;
	MIDIOUTCAPS2A * myCaps2A;
	MIDIOUTCAPS2W * myCaps2W;
	
	CHAR synthName[] = "BASSMIDI Driver\0";
	WCHAR synthNameW[] = L"BASSMIDI Driver\0";
	
	switch (capsSize) {
	case (sizeof(MIDIOUTCAPSA)):
		myCapsA = (MIDIOUTCAPSA *)capsPtr;
		myCapsA->wMid = 0xffff; //MM_UNMAPPED
		myCapsA->wPid = 0xffff; //MM_PID_UNMAPPED
		memcpy(myCapsA->szPname, synthName, sizeof(synthName));
		myCapsA->wTechnology = MOD_MIDIPORT;
		myCapsA->vDriverVersion = 0x0090;
		myCapsA->wVoices = 0;
		myCapsA->wNotes = 0;
		myCapsA->wChannelMask = 0xffff;
		myCapsA->dwSupport = 0;
		return MMSYSERR_NOERROR;

		break;
	case (sizeof(MIDIOUTCAPSW)):
		myCapsW = (MIDIOUTCAPSW *)capsPtr;
		myCapsW->wMid = 0xffff;
		myCapsW->wPid = 0xffff;
		memcpy(myCapsW->szPname, synthNameW, sizeof(synthNameW));
		myCapsW->wTechnology = MOD_MIDIPORT;
		myCapsW->vDriverVersion = 0x0090;
		myCapsW->wVoices = 0;
		myCapsW->wNotes = 0;
		myCapsW->wChannelMask = 0xffff;
		myCapsW->dwSupport = 0;
		return MMSYSERR_NOERROR;

		break;
	case (sizeof(MIDIOUTCAPS2A)):
		myCaps2A = (MIDIOUTCAPS2A *)capsPtr;
		myCaps2A->wMid = 0xffff;
		myCaps2A->wPid = 0xffff;
		memcpy(myCaps2A->szPname, synthName, sizeof(synthName));
		myCaps2A->wTechnology = MOD_MIDIPORT;
		myCaps2A->vDriverVersion = 0x0090;
		myCaps2A->wVoices = 0;
		myCaps2A->wNotes = 0;
		myCaps2A->wChannelMask = 0xffff;
		myCaps2A->dwSupport = 0;
		myCaps2A->ManufacturerGuid = CLSID_bassmidi_synth;
		myCaps2A->ProductGuid = CLSID_bassmidi_synth;
		myCaps2A->NameGuid = CLSID_bassmidi_synth;
		return MMSYSERR_NOERROR;

	case (sizeof(MIDIOUTCAPS2W)):
		myCaps2W = (MIDIOUTCAPS2W *)capsPtr;
		myCaps2W->wMid = 0xffff;
		myCaps2W->wPid = 0xffff;
		memcpy(myCaps2W->szPname, synthNameW, sizeof(synthNameW));
		myCaps2W->wTechnology = MOD_MIDIPORT;
		myCaps2W->vDriverVersion = 0x0090;
		myCaps2W->wVoices = 0;
		myCaps2W->wNotes = 0;
		myCaps2W->wChannelMask = 0xffff;
		myCaps2W->dwSupport = 0;
		myCaps2W->ManufacturerGuid = CLSID_bassmidi_synth;
		myCaps2W->ProductGuid = CLSID_bassmidi_synth;
		myCaps2W->NameGuid = CLSID_bassmidi_synth;
		return MMSYSERR_NOERROR;
		
	default:
		return MMSYSERR_ERROR;

		break;
	}

}


struct evbuf_t{
	UINT uMsg;
	DWORD	dwParam1;
	DWORD	dwParam2;
	int exlen;
	char *sysexbuffer;
};
#define EVBUFF_SIZE 512
static struct evbuf_t evbuf[EVBUFF_SIZE];
static UINT  evbwpoint=0;
static UINT  evbrpoint=0;
static UINT evbsysexpoint;

int bmsyn_buf_check(void){
	int retval;
	EnterCriticalSection(&mim_section);
	retval = (evbrpoint != evbwpoint) ? ~0 :  0;
	LeaveCriticalSection(&mim_section);
	return retval;
}

static const char sysex_gm_reset[] = { 0xF0, 0x7E, 0x7F, 0x09, 0x01, 0xF7 };
static const char sysex_gs_reset[] = { 0xF0, 0x41, 0x10, 0x42, 0x12, 0x40, 0x00, 0x7F, 0x00, 0x41, 0xF7 };
static const char sysex_xg_reset[] = { 0xF0, 0x43, 0x10, 0x4C, 0x00, 0x00, 0x7E, 0x00, 0xF7 };

int bmsyn_play_some_data(void){
	UINT uMsg;
	DWORD	dwParam1;
	DWORD	dwParam2;
	
	UINT evbpoint;
	MIDIHDR *IIMidiHdr;
	int exlen;
	char *sysexbuffer;
	int played;
		
	played=0;
		if( !bmsyn_buf_check() ){ 
			played=~0;
			return played;
		}
		do{
			EnterCriticalSection(&mim_section);
			evbpoint=evbrpoint;
			if (++evbrpoint >= EVBUFF_SIZE)
					evbrpoint -= EVBUFF_SIZE;

			uMsg=evbuf[evbpoint].uMsg;
			dwParam1=evbuf[evbpoint].dwParam1;
			dwParam2=evbuf[evbpoint].dwParam2;
		    exlen=evbuf[evbpoint].exlen;
			sysexbuffer=evbuf[evbpoint].sysexbuffer;
			
			LeaveCriticalSection(&mim_section);
			switch (uMsg) {
			case MODM_DATA:
				dwParam2 = dwParam1 & 0xF0;
				exlen = ( dwParam2 == 0xC0 || dwParam2 == 0xD0 ) ? 2 : 3;
				BASS_MIDI_StreamEvents( hStream, BASS_MIDI_EVENTS_RAW, &dwParam1, exlen );
				if ( dwParam2 == 0xB0 && ( dwParam1 & 0xFF00 ) == 0 )
				{
					if ( ( dwParam1 & 0xFF0000 ) == 0x7F0000 ) drum_channels[ dwParam1 & 0x0F ] = 1;
					else if ( ( dwParam1 & 0xFF0000 ) == 0x790000 ) drum_channels[ dwParam1 & 0x0F ] = 0;
				}
				else if ( dwParam2 == 0xC0 )
				{
					BASS_MIDI_StreamEvent( hStream, dwParam1 & 0x0F, MIDI_EVENT_DRUMS, drum_channels[ dwParam1 & 0x0F ] );
				}
				break;
			case MODM_LONGDATA:
#ifdef DEBUG
	FILE * logfile;
	logfile = fopen("c:\\dbglog2.log","at");
	if(logfile!=NULL) {
		for(int i = 0 ; i < exlen ; i++)
			fprintf(logfile,"%x ", sysexbuffer[i]);
		fprintf(logfile,"\n");
	}
	fclose(logfile);
#endif
				BASS_MIDI_StreamEvents( hStream, BASS_MIDI_EVENTS_RAW, sysexbuffer, exlen );
				if ( ( exlen == _countof( sysex_gm_reset ) && !memcmp( sysexbuffer, sysex_gm_reset, _countof( sysex_gm_reset ) ) ) ||
					( exlen == _countof( sysex_gs_reset ) && !memcmp( sysexbuffer, sysex_gs_reset, _countof( sysex_gs_reset ) ) ) ||
					( exlen == _countof( sysex_xg_reset ) && !memcmp( sysexbuffer, sysex_xg_reset, _countof( sysex_xg_reset ) ) ) ) {
					ResetDrumChannels();
				}
				else if ( exlen == 11 &&
					sysexbuffer [0] == (char)0xF0 && sysexbuffer [1] == 0x41 && sysexbuffer [3] == 0x42 &&
					sysexbuffer [4] == 0x12 && sysexbuffer [5] == 0x40 && (sysexbuffer [6] & 0xF0) == 0x10 &&
					sysexbuffer [10] == (char)0xF7)
				{
					if (sysexbuffer [7] == 2)
					{
						// GS MIDI channel to part assign
						gs_part_to_ch [ sysexbuffer [6] & 15 ] = sysexbuffer [8];
					}
					else if ( sysexbuffer [7] == 0x15 )
					{
						// GS part to rhythm allocation
						unsigned int drum_channel = gs_part_to_ch [ sysexbuffer [6] & 15 ];
						if ( drum_channel < 16 )
						{
							drum_channels [ drum_channel ] = sysexbuffer [8];
						}
					}
				}
				free(sysexbuffer);
				break;
			}
		}while(bmsyn_buf_check());	
	return played;
}

unsigned __stdcall threadfunc(LPVOID lpV){
	while(stop_thread == 0){
		Sleep(1);
		//EnterCriticalSection(&mim_section);
		bmsyn_play_some_data();
		BASS_ChannelUpdate( hStream, 1 );
		//LeaveCriticalSection(&mim_section);
	}
	stop_thread=0;
	_endthreadex(0);
	return 0;
}

BOOL IsVistaOrNewer(){
	OSVERSIONINFOEX osvi;
	BOOL bOsVersionInfoEx;

	ZeroMemory(&osvi, sizeof(OSVERSIONINFOEX));

	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
	bOsVersionInfoEx = GetVersionEx((OSVERSIONINFO*) &osvi);

	if(bOsVersionInfoEx == FALSE) return FALSE;

	if ( VER_PLATFORM_WIN32_NT==osvi.dwPlatformId && 
		 osvi.dwMajorVersion > 5 )
		return TRUE;

	return FALSE;
}



void load_settings()
{
	int config_volume;
	HKEY hKey, hSubKey;
	long lResult;
	DWORD dwType=REG_DWORD;
	DWORD dwSize=sizeof(DWORD);
	lResult = RegOpenKey(HKEY_CURRENT_USER, L"Software\\BASSMIDI Driver",&hKey);
	RegQueryValueEx(hKey, L"volume", NULL, &dwType,(LPBYTE)&config_volume, &dwSize);
	RegCloseKey( hKey);
	BASS_SetConfig(BASS_CONFIG_GVOL_STREAM,config_volume);
}

unsigned __stdcall threadfunc2(LPVOID lpV){
	unsigned i;
	HANDLE hThread = NULL;
	unsigned int thrdaddr;
	int opend=0;
	TCHAR config[1024];
	BASS_MIDI_FONT * mf;
	BASS_INFO info;
	;
	while(opend == 0) {
		Sleep(100);
		if ( BASS_Init( -1, 44100, BASS_DEVICE_LATENCY, 0, NULL ) ) {
			BASS_GetInfo(&info);
			BASS_SetConfig(BASS_CONFIG_BUFFER,max(10+info.minbuf,250));
			BASS_SetConfig(BASS_CONFIG_UPDATETHREADS, 0);
			BASS_SetConfig(BASS_CONFIG_UPDATEPERIOD, 0);
			hStream = BASS_MIDI_StreamCreate( 16, IsVistaOrNewer() ? BASS_SAMPLE_FLOAT : 0, 44100 );
			load_settings();
			if (GetWindowsDirectory(config, 1023 - 16))
			{
				_tcscat( config, _T("\\bassmidi.sflist") );
			}
			LoadFonts(config);
			if (font_count) {
				mf = malloc( sizeof(BASS_MIDI_FONT) * font_count );
				for ( i = 0; i < font_count; ++i ) {
					mf[i].font = hFonts[ font_count - i - 1 ];
					mf[i].preset = -1;
					mf[i].bank = 0;
				}
				BASS_MIDI_StreamSetFonts( hStream, mf, font_count );
				free(mf);
			}
			ResetDrumChannels();

			BASS_ChannelPlay( hStream, FALSE );
			hThread=(HANDLE)_beginthreadex(NULL,0,threadfunc,0,0,&thrdaddr);
			SetPriorityClass(hThread, REALTIME_PRIORITY_CLASS);
			SetThreadPriority(hThread, THREAD_PRIORITY_TIME_CRITICAL);
			opend = 1;
		}
	}
	hCalcThread = hThread;

	while(stop_rtthread == 0){
		Sleep(10);
	}

	BASS_StreamFree( hStream );
	hStream = 0;

	FreeFonts();

	BASS_Free();

	stop_rtthread=0;
	_endthreadex(0);
	return 0;
}

STDAPI_(LONG) modMessage(UINT uDeviceID, UINT uMsg, DWORD dwUser, DWORD dwParam1, DWORD dwParam2){
	unsigned int thrdaddr;
	DWORD tstate;
	int OCount;
	DWORD Exit;
	
	MIDIHDR *IIMidiHdr;	
	UINT evbpoint;
	
	int exlen = 0;
	char *sysexbuffer = NULL ;

	
	switch (uMsg) {
	case MODM_OPEN:
		OpenCount++;
		if ( OpenCount == 1 && modm_closed  == 1 ){
			processPriority = GetPriorityClass(GetCurrentProcess());
			SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS);
			hRtsynThread=(HANDLE)_beginthreadex(NULL,0,threadfunc2,0,0,&thrdaddr);
			modm_closed = 0;
		}
		SetPriorityClass(GetCurrentProcess(), processPriority);
		return MMSYSERR_NOERROR;
		break;
	case MODM_PREPARE:
		return MMSYSERR_NOTSUPPORTED;
		break;
	case MODM_UNPREPARE:
		return MMSYSERR_NOTSUPPORTED;
		break;
	case MODM_GETDEVCAPS:
		return modGetCaps((PVOID)dwParam1, dwParam2);
		break;
	case MODM_LONGDATA:
		IIMidiHdr = (MIDIHDR *)dwParam1;
		if( !(IIMidiHdr->dwFlags & MHDR_PREPARED) ) return MIDIERR_UNPREPARED;
		IIMidiHdr->dwFlags &= ~MHDR_DONE;
		IIMidiHdr->dwFlags |= MHDR_INQUEUE;
		IIMidiHdr = (MIDIHDR *) dwParam1;
		exlen=(int)IIMidiHdr->dwBufferLength;
		if( NULL == (sysexbuffer = (char *)malloc(exlen * sizeof(char)))){
			return MMSYSERR_NOMEM;
		}else{
			memcpy(sysexbuffer,IIMidiHdr->lpData,exlen);
#ifdef DEBUG
	FILE * logfile;
	logfile = fopen("c:\\dbglog.log","at");
	if(logfile!=NULL) {
		fprintf(logfile,"sysex %d byete\n", exlen);
		for(int i = 0 ; i < exlen ; i++)
			fprintf(logfile,"%x ", sysexbuffer[i]);
		fprintf(logfile,"\n");
	}
	fclose(logfile);
#endif
		}
		IIMidiHdr->dwFlags &= ~MHDR_INQUEUE;
		IIMidiHdr->dwFlags |= MHDR_DONE;
	case MODM_DATA:
		EnterCriticalSection(&mim_section);
		evbpoint = evbwpoint;
		if (++evbwpoint >= EVBUFF_SIZE)
			evbwpoint -= EVBUFF_SIZE;
		evbuf[evbpoint].uMsg = uMsg;
		evbuf[evbpoint].dwParam1 = dwParam1;
		evbuf[evbpoint].dwParam2 = dwParam2;
		evbuf[evbpoint].exlen=exlen;
		evbuf[evbpoint].sysexbuffer=sysexbuffer;
		LeaveCriticalSection(&mim_section);
		return MMSYSERR_NOERROR;
		break;		
	case MODM_GETNUMDEVS:
		return 0x1;
		break;
	case MODM_CLOSE:
		if ( stop_rtthread != 0 || stop_thread != 0 ) return MIDIERR_STILLPLAYING;
		--OpenCount;
/*
		if( ( OpenCount == 0) && (play_mode->id_character != 'd') ){
			int maxloop=100;
			
			stop_thread = 1;
			while( stop_thread != 0 && maxloop-- > 0) Sleep(10);
			if(stop_thread == 0) {
				stop_rtthread = 1;
				while( stop_rtthread != 0 && maxloop-- > 0) Sleep(10);
			}
			if(stop_thread != 0) TerminateThread(hCalcThread, FALSE);
			if(stop_rtthread != 0) TerminateThread(hRtsynThread, FALSE);
			
			if(maxloop == 0){
				DeleteCriticalSection(&mim_section);
				InitializeCriticalSection(&mim_section);
			}
			stop_rtthread = 0;
			stop_thread = 0;
			CloseHandle(hRtsynThread);
			CloseHandle(hCalcThread);
			SetPriorityClass(GetCurrentProcess(), processPriority);
			modm_closed=1;
		}else{ 
*/
			if(OpenCount < 0){
				OpenCount = 0;
				return MMSYSERR_NOTENABLED;
			}
//		}
		return MMSYSERR_NOERROR;
		break;
	default:
		return MMSYSERR_NOERROR;
		break;
	}
}


BASSMIDIDrv WinMM Driver
********************************

First-time Installation
-----------------------

 1) Run the installer. It should register the driver
    with the system.
 2) Using the configuration tool included, configure 
    the desired soundfont usage.

Upgrading
---------

 1) Download the newly released version.
 2) Run the new installer. You will be prompted to uninstall
    the previous version.
 3) Run the installer again, following the instructions
    for "First-time Installation.
//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by sfpacker.rc
//
#define IDD_GUIDGEN_DIALOG              102
#define IDP_ERR_INIT_OLE                102
#define IDD_DIALOG                      102
#define IDS_FORMATS                     104
#define IDS_STRING105                   105
#define IDS_STRING106                   106
#define IDS_STRING107                   107
#define IDR_MAINFRAME                   128
#define IDC_RADIO1                      1000
#define ID_PACK                         1000
#define IDC_RADIO2                      1001
#define IDC_FILENAME                    1001
#define IDC_RADIO3                      1002
#define IDC_RADIO4                      1003
#define IDC_COMPTYPE                    1003
#define IDC_RESULTS                     1004
#define IDC_COMPRESSION                 1004
#define IDC_NEWGUID                     1005
#define IDC_COMPSTR                     1005
#define IDC_PATH                        1006
#define IDC_BROWSE                      1007
#define IDC_BUTTON2                     1008
#define IDC_APPLY                       1008
#define IDP_ERR_CREATE_GUID             2000
#define IDP_ERR_OPEN_CLIP               2001
#define IDS_ABOUTBOX                    2002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif

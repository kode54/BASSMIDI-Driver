/* Copyright (C) 2011 Chris Moeller, Brad Miller
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 2.1 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "BASSDriver.h"

BASSDriver::BASSDriver() {
	hStream = 0;
	hFonts = NULL;
	font_count = 0;
}

BASSDriver::~BASSDriver() {
}

void BASSDriver::ResetDrumChannels()
{
	static const BYTE part_to_ch[16] = {9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15};
	unsigned i;
	memset( drum_channels, 0, sizeof( drum_channels ) );
	drum_channels[ 9 ] = 1;
	memcpy( gs_part_to_ch, part_to_ch, sizeof( gs_part_to_ch ) );
	if ( hStream )
	{
		for ( i = 0; i < 16; ++i )
		{
			BASS_MIDI_StreamEvent( hStream, i, MIDI_EVENT_DRUMS, drum_channels[ i ] );
		}
	}
}

void BASSDriver::FreeFonts()
{
	unsigned i;
	if ( hFonts && font_count )
	{
		for ( i = 0; i < font_count; ++i )
		{
			BASS_MIDI_FontFree( hFonts[ i ] );
		}
		free( hFonts );
		hFonts = NULL;
		font_count = 0;
	}
}

void BASSDriver::LoadFonts(const TCHAR * name)
{
	const DWORD bass_flags =
#ifdef UNICODE
		BASS_UNICODE
#else
		0
#endif
		;

	FreeFonts();

	if (name && *name)
	{
		const TCHAR * ext = _tcsrchr( name, _T('.') );
		if ( ext ) ext++;
		if ( !_tcsicmp( ext, _T("sf2") ) || !_tcsicmp( ext, _T("sf2pack") ) )
		{
			font_count = 1;
			hFonts =(HSOUNDFONT*) malloc( sizeof(HSOUNDFONT) );
			*hFonts = BASS_MIDI_FontInit( name, bass_flags );
		}
		else if ( !_tcsicmp( ext, _T("sflist") ) )
		{
			FILE * fl = _tfopen( name, _T("r, ccs=UTF-8") );
			font_count = 0;
			if ( fl )
			{
				TCHAR path[1024], fontname[1024], temp[1024];
				const TCHAR * filename = _tcsrchr( name, _T('\\') ) + 1;
				if ( filename == (void*)1 ) filename = _tcsrchr( name, _T(':') ) + 1;
				if ( filename == (void*)1 ) filename = name;
				_tcsncpy( path, name, filename - name );
				path[ filename - name ] = 0;
				while ( !feof( fl ) )
				{
					TCHAR * cr;
					if( !_fgetts( fontname, 1024, fl ) ) break;
					fontname[1023] = 0;
					cr = _tcsrchr( fontname, _T('\n') );
					if ( cr ) *cr = 0;
					if ( isalpha( fontname[0] ) && fontname[1] == _T(':') )
					{
						cr = fontname;
					}
					else
					{
						_tcscpy( temp, path );
						_tcscat( temp, fontname );
						cr = temp;
					}
					font_count++;
					hFonts = (HSOUNDFONT*)realloc( hFonts, sizeof(HSOUNDFONT) * font_count );
					hFonts[ font_count - 1 ] = BASS_MIDI_FontInit( cr, bass_flags );
				}
				fclose( fl );
			}
		}
	}
}

void BASSDriver::load_settings()
{
	int config_volume;
	HKEY hKey, hSubKey;
	long lResult;
	DWORD dwType=REG_DWORD;
	DWORD dwSize=sizeof(DWORD);
	lResult = RegOpenKey(HKEY_CURRENT_USER, _T("Software\\BASSMIDI Driver"),&hKey);
	RegQueryValueEx(hKey, _T("volume"), NULL, &dwType,(LPBYTE)&config_volume, &dwSize);
	RegCloseKey( hKey);
	BASS_SetConfig(BASS_CONFIG_GVOL_STREAM,config_volume);
}

void BASSDriver::CloseBASSDriver()
{
	BASS_StreamFree( hStream );
	hStream = 0;
	FreeFonts();
	BASS_Free();
}

BOOL BASSDriver::OpenBASSDriver()
{
	unsigned i;
	TCHAR config[1024];
	BASS_MIDI_FONT * mf;
	if ( BASS_Init( 0, 44100, 0, 0, NULL ) ) {
		BASS_SetConfig( BASS_CONFIG_MIDI_VOICES, 256 );
		hStream = BASS_MIDI_StreamCreate( 16, BASS_STREAM_DECODE, 44100 );
		load_settings();
		if (GetWindowsDirectory(config, 1023 - 16))
		{
			_tcscat( config, _T("\\bassmidi.sflist") );
		}
		LoadFonts(config);
		if (font_count) {
			mf = (BASS_MIDI_FONT*)malloc( sizeof(BASS_MIDI_FONT) * font_count );
			for ( i = 0; i < font_count; ++i ) {
				mf[i].font = hFonts[ font_count - i - 1 ];
				mf[i].preset = -1;
				mf[i].bank = 0;
			}
			BASS_MIDI_StreamSetFonts( hStream, mf, font_count );
			free(mf);
		}
		ResetDrumChannels();
		return TRUE;
	}
	return FALSE;
	
}

void BASSDriver::ProcessMIDIMessage(DWORD dwParam1)
{
	int exlen;
	DWORD	dwParam2;
	dwParam2 = dwParam1 & 0xF0;
	exlen = ( dwParam2 == 0xC0 || dwParam2 == 0xD0 ) ? 2 : 3;
	BASS_MIDI_StreamEvents( hStream, BASS_MIDI_EVENTS_RAW, &dwParam1, exlen );
	if ( dwParam2 == 0xB0 && ( dwParam1 & 0xFF00 ) == 0 )
	{
		if ( ( dwParam1 & 0xFF0000 ) == 0x7F0000 ) drum_channels[ dwParam1 & 0x0F ] = 1;
		else if ( ( dwParam1 & 0xFF0000 ) == 0x790000 ) drum_channels[ dwParam1 & 0x0F ] = 0;
	}
	else if ( dwParam2 == 0xC0 )
	{
		BASS_MIDI_StreamEvent( hStream, dwParam1 & 0x0F, MIDI_EVENT_DRUMS, drum_channels[ dwParam1 & 0x0F ] );
	}
}

void BASSDriver::ProcessSysEx(unsigned char *sysexbuffer,int exlen)
{
	const char sysex_gm_reset[] = { 0xF0, 0x7E, 0x7F, 0x09, 0x01, 0xF7 };
	const char sysex_gs_reset[] = { 0xF0, 0x41, 0x10, 0x42, 0x12, 0x40, 0x00, 0x7F, 0x00, 0x41, 0xF7 };
	const char sysex_xg_reset[] = { 0xF0, 0x43, 0x10, 0x4C, 0x00, 0x00, 0x7E, 0x00, 0xF7 };

	BASS_MIDI_StreamEvents( hStream, BASS_MIDI_EVENTS_RAW, sysexbuffer, exlen );
	if ( ( exlen == _countof( sysex_gm_reset ) && !memcmp( sysexbuffer, sysex_gm_reset, _countof( sysex_gm_reset ) ) ) ||
		( exlen == _countof( sysex_gs_reset ) && !memcmp( sysexbuffer, sysex_gs_reset, _countof( sysex_gs_reset ) ) ) ||
		( exlen == _countof( sysex_xg_reset ) && !memcmp( sysexbuffer, sysex_xg_reset, _countof( sysex_xg_reset ) ) ) ) {
			ResetDrumChannels();
	}
	else if ( exlen == 11 &&
		sysexbuffer [0] == 0xF0 && sysexbuffer [1] == 0x41 && sysexbuffer [3] == 0x42 &&
		sysexbuffer [4] == 0x12 && sysexbuffer [5] == 0x40 && (sysexbuffer [6] & 0xF0) == 0x10 &&
		sysexbuffer [10] == 0xF7)
	{
		if (sysexbuffer [7] == 2)
		{
			// GS MIDI channel to part assign
			gs_part_to_ch [ sysexbuffer [6] & 15 ] = sysexbuffer [8];
		}
		else if ( sysexbuffer [7] == 0x15 )
		{
			// GS part to rhythm allocation
			unsigned int drum_channel = gs_part_to_ch [ sysexbuffer [6] & 15 ];
			if ( drum_channel < 16 )
			{
				drum_channels [ drum_channel ] = sysexbuffer [8];
			}
		}
	}
}


void BASSDriver::Render(short * samples, int len)
{
	BASS_ChannelGetData(hStream,samples,len * sizeof(short) * 2);
}
